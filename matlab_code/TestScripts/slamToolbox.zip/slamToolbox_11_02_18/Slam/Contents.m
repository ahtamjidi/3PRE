% Simultaneous localization and mapping.
%
% Map management
%   addToMap       - Add Gaussian to Map.
%   newRange       - New map range.
%   usedRange      - Used map range.
%   newLmk         - Get a new landmark.
%   smartDeleteLmk - Smart deletion of landmarks.
%
% Time management
%   samplePeriod   - Sample period.
