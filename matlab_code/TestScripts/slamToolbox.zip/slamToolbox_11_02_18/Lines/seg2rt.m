function [rt,RT_s] = seg2rt(seg)

% SEG2RT Segment to rho-theta conversion.
%   SEG2RT(S) converts the segment S=[x1;y1;x2;y2] to its polar rho-theta
%   representation.
%
%   [RT, RT_s] = SEG2RT(S) returns the Jacobian of RT wrt S.
%
%   Copyright 2008-2009 Joan Sola @ LAAS-CNRS.

if nargout == 1
    
    rt = hmgLin2rt(seg2hmgLin(seg));
    
else
    
    [hm,HM_s] = seg2hmgLin(seg);
    [rt,RT_hm] = hmgLin2rt(hm);
    
    RT_s = RT_hm*HM_s;

end



% ========== End of function - Start GPL license ==========


%   # START GPL LICENSE

%---------------------------------------------------------------------
%
%   This file is part of SLAMTB, a SLAM toolbox for Matlab.
%
%   SLAMTB is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   SLAMTB is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with SLAMTB.  If not, see <http://www.gnu.org/licenses/>.
%
%---------------------------------------------------------------------

%   SLAMTB is Copyright 2007,2008,2009 
%   by Joan Sola, David Marquez and Jean Marie Codol @ LAAS-CNRS.
%   See on top of this file for its particular copyright.

%   # END GPL LICENSE

