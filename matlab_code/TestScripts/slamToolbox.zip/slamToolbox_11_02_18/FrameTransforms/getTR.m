function [T,R,Rt] = getTR(F)

% GETTR Get translation vector and rotation matrix
%
% [T,R] = GETTR(F) gets version of T and R
% from frame S, where S is a structure containing:
%   X = [T;Q] : frame
%   R : rotation matrix
%
% [T,R,Rt] = GETTR(...) gives also the transposed R

%   Copyright 2008-2009 Joan Sola @ LAAS-CNRS.

T = F.t;
R = F.R;
if nargout == 3
    Rt = F.Rt;
end




% ========== End of function - Start GPL license ==========


%   # START GPL LICENSE

%---------------------------------------------------------------------
%
%   This file is part of SLAMTB, a SLAM toolbox for Matlab.
%
%   SLAMTB is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%   SLAMTB is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public License
%   along with SLAMTB.  If not, see <http://www.gnu.org/licenses/>.
%
%---------------------------------------------------------------------

%   SLAMTB is Copyright 2007,2008,2009 
%   by Joan Sola, David Marquez and Jean Marie Codol @ LAAS-CNRS.
%   See on top of this file for its particular copyright.

%   # END GPL LICENSE

