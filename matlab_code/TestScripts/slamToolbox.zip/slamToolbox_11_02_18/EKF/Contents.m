% Extended Kalman Filter.
%
% Files
%   innovation - Innovation of an observation.
%   correctBlockEkf - Correct in block-defined EKF.
%   predictBlockEkf - Covariance predict in block-defined EKF.
