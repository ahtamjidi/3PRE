% AO simulation - software for simulation of em wave propagation through turbulence and optics
% Based on Arroyo from Dr. Matthew Britton.
% 
% Copyright (c) 2011 National Observatories Of China.  Written by
% Dr. Lu, Feng.  For comments or questions about this software,
% please contact the author at jacobfeng@gmail.com.
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as  published by the
% Free Software Foundation; either version 2 of the License, or (at your
% option) any later version.
% 
% This program is provided "as is" and distributed in the hope that it
% will be useful, but WITHOUT ANY WARRANTY; without even the implied
% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  In no
% event shall National Observatories of China be liable to any party
% for direct, indirect, special, incidental or consequential damages,
% including lost profits, arising out of the use of this software and its
% documentation, even if National Observatories of China has been
% advised of the possibility of such damage.   The National Observatories of 
% China has no obligation to provide maintenance, support, updates,
% enhancements or modifications.  See the GNU General Public License for
% more details.
% 
% You should have received a copy of the GNU General Public License along
% with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.

classdef Transformation
    properties
        % refer to http://www.cosc.brocku.ca/Offerings/3P98/course/lectures/2d_3d_xforms/
        transformationMatrix = eye(4);
    end
    methods 
        function obj = Transformation(varargin)
        % constructor
        % 1. obj = Transformation() % null constructor
        % 2. obj = Transformation(transformation) % copy constructor
        % 3. obj = Transformation(transformationmatrix) % build directly
        % from transformation matrix
            if nargin == 0
                obj.transformationMatrix = eye(4);
            elseif nargin==1 && isa(varargin{1}, 'Transformation')
                tr= varargin{1};
                obj.transformationMatrix = tr.transformationMatrix;
            elseif nargin==1
                obj.transformationMatrix = varargin{1};
            end           
        end
        function obj = setTransformation(obj, tr)
            obj.transformationMatrix = tr.transformationMatrix;   
        end
        function result = transform(obj, in)
        % numerical error can be negligeable
        % function type
        % 1. point = Transformation.transform(point)
        % 2. vector = Transformation.transform(vector)
            result = in;
            tm = obj.transformationMatrix; %limitation caused by non handle class  
            if isa(in,'Point') || isa(in, 'Frame') 
                result.coors(1) = sum(tm(1,1:3).*(in.coors')) + tm(1,4);
                result.coors(2) = sum(tm(2,1:3).*(in.coors')) + tm(2,4);
                result.coors(3) = sum(tm(3,1:3).*(in.coors')) + tm(3,4);
            else isa(in, 'Vector')
                result.coors(1) = sum(tm(1,1:3).*(in.coors'));
                result.coors(2) = sum(tm(2,1:3).*(in.coors'));
                result.coors(3) = sum(tm(3,1:3).*(in.coors'));     
            end
        end
        function result = eq(a,b)
            if ~isa(a,'Transformation') || ~isa(b,'Transformation')
               error('input argument type error'); 
            end
            if a.transformationMatrix == b.transformationMatrix
                result = true;
            else
                result = false;
            end
        end
        function result = ne(a,b)
            if a==b
                result = false;
            else
                result = true;
            end 
        end
        function result = mtimes(tt1, tt2)
        % Multiply two transformations to yield a 3rd.
        % The application of these transformations
        % to a point, vector, or frame is defined
        % in the sense that first the transformation tt2
        % is applied, and then the transformation tt1
        % is applied.  In matrix form, this means
        % that this function performs a left matrix
        % multiply of the transformation tt2 by the 
        % transformation tt1.  That is, the arguments
        % are read right to left.     
            result = Transformation(tt1.transformationMatrix*tt2.transformationMatrix);
        end    
        function result = inverse(obj)
        % can't directly inverse the transformation matrix
            mat = obj.transformationMatrix;
            dx = mat(1,4); dy = mat(2,4); dz = mat(3,4);
            mat = mat(1:3,1:3);
            matinv = inv(mat);
            mat = eye(4); mat(1:3, 1:3) = matinv;
            transformation1 = Transformation(mat);
            mat = eye(4); 
            mat(1,4) = dx; mat(2,4) = dy; mat(3,4) = dz; % this part is different from Arroyo definition
            transformation2 = Transformation(mat);
            result = transformation2 * transformation1;
        end
    end
end

