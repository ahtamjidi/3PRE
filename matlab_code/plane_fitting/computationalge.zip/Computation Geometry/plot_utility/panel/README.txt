
INTRODUCTION

Panel Version 1 was released in 2008. It has been in use since, and improved, and converted into a classdef (single file) implementation. Panel Version 2 is a public release of these changes.



INSTALLATION

To install panel, place the file "panel.m" on your Matlab path.



DOCUMENTATION

Documentation is provided in three forms.

1) The folder "docs" contains introductory information.
2) "doc panel" at the Matlab prompt provides reference information.
3) The folder "demo" contains scripts which you can review one by one to learn how to use Panel - this constitutes the User Guide.



CHANGE LOG

22/05/2011 First Public Release Version 2.0


