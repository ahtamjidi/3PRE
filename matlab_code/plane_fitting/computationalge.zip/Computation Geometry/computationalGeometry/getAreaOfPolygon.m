% AO simulation - software for simulation of em wave propagation through turbulence and optics
% Based on Arroyo from Dr. Matthew Britton.
% 
% Copyright (c) 2011 National Observatories Of China.  Written by
% Dr. Lu, Feng.  For comments or questions about this software,
% please contact the author at jacobfeng@gmail.com.
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as  published by the
% Free Software Foundation; either version 2 of the License, or (at your
% option) any later version.
% 
% This program is provided "as is" and distributed in the hope that it
% will be useful, but WITHOUT ANY WARRANTY; without even the implied
% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  In no
% event shall National Observatories of China be liable to any party
% for direct, indirect, special, incidental or consequential damages,
% including lost profits, arising out of the use of this software and its
% documentation, even if National Observatories of China has been
% advised of the possibility of such damage.   The National Observatories of 
% China has no obligation to provide maintenance, support, updates,
% enhancements or modifications.  See the GNU General Public License for
% more details.
% 
% You should have received a copy of the GNU General Public License along
% with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.

function result = getAreaOfPolygon(polygon_vertices)
    % input point sequence must be sorted before using
    % function type
    % double = getAreaOfPolygon(cell(Point))
    nvertices = length(polygon_vertices);
    if(nvertices<3)
       error('getAreaOfPolygon() error, number of vertices is less than 3');
    end

    index1 = 2;
    tmpV1 = polygon_vertices{index1}-polygon_vertices{1};
    while(tmpV1.length()<Frame.precision)
       index1 = index1+1;
       tmpV1 = polygon_vertices{index1}-polygon_vertices{1}; 
    end
    index2 = index1+1;
    tmpV2 = polygon_vertices{index2}-polygon_vertices{index1};
    while(tmpV2.length()<Frame.precision)
        index2 = index2+1;
        tmpV2 = polygon_vertices{index2}-polygon_vertices{index1};
    end

    out_of_plane_normal = tmpV1*tmpV2;
    out_of_plane_normal = out_of_plane_normal.*(1/out_of_plane_normal.length());
    polygon_area = 0;
    for i=3:nvertices
       %calculate the two triangle, and sum up for the are of the polygon 
       tmpv1 = polygon_vertices{i-1} - polygon_vertices{1};
       tmpv2 = polygon_vertices{i}   - polygon_vertices{1};
       triangle_area = .5* ((tmpv1*tmpv2).*out_of_plane_normal);
       if triangle_area==inf
          error('getAreaOfPolygon() error, infinite area calculated');
       else
          polygon_area = polygon_area + triangle_area; 
       end
    end
    result = polygon_area;
end