% AO simulation - software for simulation of em wave propagation through turbulence and optics
% Based on Arroyo from Dr. Matthew Britton.
% 
% Copyright (c) 2011 National Observatories Of China.  Written by
% Dr. Lu, Feng.  For comments or questions about this software,
% please contact the author at jacobfeng@gmail.com.
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as  published by the
% Free Software Foundation; either version 2 of the License, or (at your
% option) any later version.
% 
% This program is provided "as is" and distributed in the hope that it
% will be useful, but WITHOUT ANY WARRANTY; without even the implied
% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  In no
% event shall National Observatories of China be liable to any party
% for direct, indirect, special, incidental or consequential damages,
% including lost profits, arising out of the use of this software and its
% documentation, even if National Observatories of China has been
% advised of the possibility of such damage.   The National Observatories of 
% China has no obligation to provide maintenance, support, updates,
% enhancements or modifications.  See the GNU General Public License for
% more details.
% 
% You should have received a copy of the GNU General Public License along
% with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.

function result = reorder(intersection_vertices, sense_of_rotation)
% function type
% cell(point) = reorder(cell(point), vector);
% this function only puts points regarding to the first vertices that has different orientation then sense_of_rotation to the front of the queue 
    tmp = Point();
    for i=2:(length(intersection_vertices)-1)
       for j=(i+1):length(intersection_vertices)
          tmpVi1 = intersection_vertices{i} - intersection_vertices{1};
          tmpVj1 = intersection_vertices{j} - intersection_vertices{1};
          cross = tmpVi1*tmpVj1;
          if(cross.*sense_of_rotation <0)
              tmp = intersection_vertices{i};
              intersection_vertices{i} = intersection_vertices{j};
              intersection_vertices{j} = tmp;
          end
       end
    end
    result = intersection_vertices;
end