% AO simulation - software for simulation of em wave propagation through turbulence and optics
% Based on Arroyo from Dr. Matthew Britton.
% 
% Copyright (c) 2011 National Observatories Of China.  Written by
% Dr. Lu, Feng.  For comments or questions about this software,
% please contact the author at jacobfeng@gmail.com.
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as  published by the
% Free Software Foundation; either version 2 of the License, or (at your
% option) any later version.
% 
% This program is provided "as is" and distributed in the hope that it
% will be useful, but WITHOUT ANY WARRANTY; without even the implied
% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  In no
% event shall National Observatories of China be liable to any party
% for direct, indirect, special, incidental or consequential damages,
% including lost profits, arising out of the use of this software and its
% documentation, even if National Observatories of China has been
% advised of the possibility of such damage.   The National Observatories of 
% China has no obligation to provide maintenance, support, updates,
% enhancements or modifications.  See the GNU General Public License for
% more details.
% 
% You should have received a copy of the GNU General Public License along
% with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.

function result = getRayRayIntersection(tp1, tv1, tp2, tv2)
% function type is point = getRayRayIntersection(point, vector, point,
% vector)
% Return the point of intersection between a ray extending from
% o_a in the direction n_a, and a ray extending from o_b in the
% direction n_b.
% 
% WARNING:  this function can return inaccurate results due to 
% numerical roundoff.  Quantifying the limits of validity of this
% function is a work in progress.

    % ensure vectors are not NULL
    if(tv1.length()<Frame.precision || tv2.length()<Frame.precision)
       error('input vector should not be NULL'); 
    end

    % ensure vectors are not parallel
    tmp = tv1*tv2;
    if(tmp.length()*(1/tv1.length()/tv2.length())<Frame.precision)
       error('input vector should not be parallel'); 
    end

    % ensure points are unique
    tv3 = tp1-tp2;
    if(tv3.length()<Frame.precision)
       error('input points should be unique'); 
    end

    % ensure vectors are coplanar
    tmp = tv1*tv2;
    if(abs((tmp.*tv3)/tv1.length()/tv2.length()/tv3.length())>Frame.precision)
       error('input argument is not coplanar');
    end

    % law of sines, using cross products, to get the vector connecting tp1 to the
    % point of intersection.  The direction of the vector is also checked to ensure
    % that we get the right one.
    tmpVec1 = tv2*tv3;
    tmpVec2 = tv1*tv2;
    mag = tv1*(tmpVec1.length()/tmpVec2.length());
    tmpVec1 = tv2*(tp1+mag-tp2);
    tmpVec2 = tv2*(tp1-mag-tp2);
    if(tmpVec1.length()>tmpVec2.length())
       result = tp1-mag;
       return;
    end
    result = tp1+mag;
end